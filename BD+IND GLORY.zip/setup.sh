#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
#   ARIAN - Termux Auto Setup Script
# ==========================================

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$DIR/setup.log"
: > "$LOG"

export DEBIAN_FRONTEND=noninteractive

R='\033[0m'
B='\033[1m'
c() { printf '\033[38;5;%sm' "$1"; }

tput civis 2>/dev/null
trap 'tput cnorm 2>/dev/null; printf "\033[0m\n"' EXIT
trap 'echo; echo -e "$(c 196)${B}✖ Cancelled by user${R}"; exit 1' INT

# ---------- Rainbow text ----------
rainbow() {
  local text="$1" i=0 ch
  local colors=(196 202 208 214 220 226 190 154 118 82 46 47 48 49 50 51 45 39 33 27 21 57 93 129 165 201 200 199)
  while IFS= read -r -n1 ch; do
    [ -z "$ch" ] && ch=" "
    printf '%b%s' "$(c ${colors[$((i % ${#colors[@]}))]})" "$ch"
    i=$((i+1))
  done <<< "$text"
  printf '%b' "$R"
}

# ---------- Logo ----------
logo() {
  clear
  local lines=(
"   █████╗ ██████╗ ██╗ █████╗ ███╗   ██╗"
"  ██╔══██╗██╔══██╗██║██╔══██╗████╗  ██║"
"  ███████║██████╔╝██║███████║██╔██╗ ██║"
"  ██╔══██║██╔══██╗██║██╔══██║██║╚██╗██║"
"  ██║  ██║██║  ██║██║██║  ██║██║ ╚████║"
"  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝"
  )
  local cols=(196 208 226 46 51 201)
  echo
  for i in "${!lines[@]}"; do
    echo -e "${B}$(c ${cols[$i]})${lines[$i]}${R}"
    sleep 0.12
  done
  echo
  echo -ne "  "; rainbow "══════════════ ⚡ AUTO SETUP TOOL ⚡ ══════════════"; echo
  echo -e "  $(c 245)Developed by $(c 226)${B}ARIAN${R}"
  echo
  sleep 0.5
}

# ---------- Lightning spinner ----------
# Usage: run_task "message" command...
run_task() {
  local msg="$1"; shift
  local frames=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
  local colors=(196 202 208 214 220 226 118 46 51 39 33 129 201 199)
  local i=0

  ( "$@" >> "$LOG" 2>&1 ) &
  local pid=$!

  while kill -0 "$pid" 2>/dev/null; do
    local col=${colors[$((i % ${#colors[@]}))]}
    local col2=${colors[$(((i+5) % ${#colors[@]}))]}
    printf '\r  %b%s%b %b%s%b\033[K' "$(c $col)${B}" "${frames[$((i % 10))]}" "$R" "$(c $col2)" "$msg" "$R"
    i=$((i+1))
    sleep 0.08
  done

  wait "$pid"
  local rc=$?
  if [ $rc -eq 0 ]; then
    printf '\r  %b✔%b %b%s%b\033[K\n' "$(c 46)${B}" "$R" "$(c 118)" "$msg" "$R"
  else
    printf '\r  %b✖%b %b%s (failed)%b\033[K\n' "$(c 196)${B}" "$R" "$(c 203)" "$msg" "$R"
  fi
  return $rc
}

# ---------- Verified / skip line ----------
verified() {   # verified "label" "detail"
  printf '  %b✔%b %b%s%b %b[verified%s - skipped]%b\n' \
    "$(c 46)${B}" "$R" "$(c 117)" "$1" "$R" "$(c 245)" "${2:+: $2}" "$R"
  sleep 0.03
}

info() { echo -e "  $(c 51)${B}➜${R} $(c 159)$1${R}"; }
fail() { echo -e "\n  $(c 196)${B}✖ $1${R}\n  $(c 245)Check log: $LOG${R}\n"; exit 1; }

# ---------- Module table (pip-name:import-name) ----------
MODS=(
  "httpx:httpx"
  "google-play-scraper:google_play_scraper"
  "pycryptodome:Crypto"
  "protobuf-decoder:protobuf_decoder"
  "protobuf:google.protobuf"
  "requests:requests"
  "aiohttp:aiohttp"
  "flask:flask"
)

# Prints "pip-name|1or0|version" for every module (one fast Python call)
scan_modules() {
  python - "${MODS[@]}" <<'PY' 2>/dev/null
import sys, importlib.util
import importlib.metadata as md
for item in sys.argv[1:]:
    dist, imp = item.split(":")
    try:
        found = importlib.util.find_spec(imp) is not None
    except Exception:
        found = False
    ver = "?"
    if found:
        try:
            ver = md.version(dist)
        except Exception:
            pass
    print(f"{dist}|{1 if found else 0}|{ver}")
PY
}

# ============ START ============
logo

# ---------- 1. Storage permission ----------
info "Checking storage permission..."
if [ ! -d "$HOME/storage" ]; then
  echo -e "  $(c 226)⚠ Permission not granted! Requesting now, please tap 'Allow'...${R}"
  termux-setup-storage
  for t in $(seq 1 30); do
    [ -d "$HOME/storage" ] && break
    printf '\r  %b⏳ Waiting for permission... (%ss)%b\033[K' "$(c 214)" "$t" "$R"
    sleep 1
  done
  echo
fi
if [ -d "$HOME/storage" ]; then
  verified "Storage permission" "granted"
else
  echo -e "  $(c 208)⚠ Storage permission not found, continuing anyway...${R}"
fi
echo

# ---------- 2. Python ----------
NEED_UPDATE=0
if command -v python >/dev/null 2>&1 && python -c "import sys" >/dev/null 2>&1; then
  PYV="$(python --version 2>&1 | awk '{print $2}')"
  verified "Python" "v$PYV"
else
  NEED_UPDATE=1
  run_task "Installing Python..." \
    bash -c 'pkg update -y && pkg install -y python' \
    || fail "Python installation failed"
  command -v python >/dev/null 2>&1 || fail "Python not found after installation"
fi

# ---------- 3. Scan modules ----------
declare -A OK VER
while IFS='|' read -r d s v; do
  OK["$d"]="$s"; VER["$d"]="$v"
done < <(scan_modules)

MISSING=0
for item in "${MODS[@]}"; do
  d="${item%%:*}"
  [ "${OK[$d]:-0}" = "1" ] || MISSING=$((MISSING+1))
done
[ "$MISSING" -gt 0 ] && NEED_UPDATE=1

# ---------- 4. Update (only if something is missing) ----------
if [ "$NEED_UPDATE" -eq 1 ]; then
  run_task "Updating packages..." \
    bash -c 'apt-get update -y && apt-get -y -o Dpkg::Options::=--force-confold upgrade' \
    || fail "Package update failed"

  if [ "$MISSING" -gt 0 ]; then
    if ! python -m pip --version >/dev/null 2>&1; then
      run_task "Installing pip..." bash -c 'pkg install -y python-pip' \
        || fail "pip installation failed"
    fi
    if ! command -v clang >/dev/null 2>&1; then
      run_task "Installing build tools..." \
        bash -c 'pkg install -y clang make libffi openssl rust binutils' \
        || fail "Build tools installation failed"
    fi
  fi
else
  verified "Package update" "not needed"
fi
echo

# ---------- 5. Install / verify modules one by one ----------
total=${#MODS[@]}
n=0
for item in "${MODS[@]}"; do
  n=$((n+1))
  d="${item%%:*}"
  imp="${item##*:}"
  if [ "${OK[$d]:-0}" = "1" ]; then
    verified "[$n/$total] $d" "v${VER[$d]}"
  else
    run_task "[$n/$total] Installing $d..." \
      python -m pip install --upgrade "$d" \
      || fail "Failed to install $d"
    if python -c "import $imp" >>"$LOG" 2>&1; then
      echo -e "      $(c 46)${B}✔ $d verified after install${R}"
    else
      fail "$d installed but could not be imported"
    fi
  fi
done

echo
echo -ne "  "; rainbow "══════════ ✅ ALL $total MODULES VERIFIED ✅ ══════════"; echo
echo

# ---------- 6. Run main.py ----------
cd "$DIR" || fail "Could not enter the script folder"
if [ ! -f "main.py" ]; then
  fail "main.py not found in this folder ($DIR)"
fi

info "Launching main.py..."
sleep 1
tput cnorm 2>/dev/null
echo
python main.py
